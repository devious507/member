<?php

include_once("../project.php");
include_once("include/GoogleMap.php");
include_once("include/JSMin.php");

$map = new GoogleMapAPI();
$map->_minify_js=isset($_REQUEST['min'])?FALSE:TRUE;
$map->setWidth('100%');
$map->setHeight('100%');
if(isset($_GET['cluster']) && $_GET['cluster'] == 'false') {
} else {
	// Enable Marker Clustering
	 $map->enableClustering();
	// //Set options (passing nothing to set defaults, just demonstrating usage
	 $map->setClusterOptions();
	 $map->setClusterLocation("include/markerclusterer_compiled.js");
}



$year=date('Y');
if(date('m') > 4) {
	$year++;
}

$sql = 'select namelast,namefirst,lat,lon FROM members WHERE expiresyear >='.$year.' AND lat IS NOT NULL AND lon IS NOT NULL;';
$db=myDB('../');
$res = simpleQuery($sql,true,$db); 
$row = $res->fetch(PDO::FETCH_ASSOC);
	//print '<pre>';
while(($row=$res->fetch(PDO::FETCH_ASSOC))==true) {
	$name = $row['NameFirst'].' '.$row['NameLast'];
	$lat=$row['lat'];
	$lon=$row['lon'];
	$map->addMarkerByCoords($lon,$lat,'',$name);
}
	//exit();

?>
<html>
<head>
<?=$map->getHeaderJS();?>
<?=$map->getMapJS();?>
</head>
<body>
<?=$map->printOnLoad();?>
<?=$map->printMap();?>
<?=$map->printSidebar();?>
</body>
</html>
